import json,pathlib,subprocess 
root=pathlib.Path.cwd() 
archive=root/r'storage\memory\archive\transition_after_telegram_bridge_to_first_real_listing_v1.json' 
data=json.loads(archive.read_text(encoding='utf-8')) if archive.exists() else {} 
safe_runtime={'telegram_runtime_ready':False,'n8n_workflow_ready':False,'eBay_publish_ready':False} 
if not data.get('confirmed_facts',{}).get('token_refreshed',False): subprocess.run(['py','storage\\tools\\safe_ebay_token_refresh_v1.py'],check=True); safe_runtime['eBay_publish_ready']=True 
if data.get('n8n_assets_exist',False): safe_runtime['n8n_workflow_ready']=True 
if data.get('telegram_bridge')=='main_synced_token_guard_locked_existing_telegram_bridge_connected': safe_runtime['telegram_runtime_ready']=True 
with open(root/r'storage\tools\safe_live_activation_output.json','w',encoding='utf-8') as f: json.dump({'live_runtime_safe_ready':safe_runtime},f) 
