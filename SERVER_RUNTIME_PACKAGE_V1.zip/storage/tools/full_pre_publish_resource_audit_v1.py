import json,pathlib,subprocess,datetime,os
root=pathlib.Path.cwd()
def read_json(x):
    try: return json.loads((root/x).read_text(encoding="utf-8"))
    except Exception as e: return {"_error":str(e),"_path":str(x)}
def exists(x): return (root/x).exists()
def globlist(pattern,limit=50): return [str(p.relative_to(root)) for p in root.glob(pattern) if p.is_file()][:limit]
git_status=subprocess.run(["git","status","--short"],cwd=str(root),capture_output=True,text=True,encoding="utf-8",errors="replace")
git_log=subprocess.run(["git","log","-1","--oneline"],cwd=str(root),capture_output=True,text=True,encoding="utf-8",errors="replace")
telegram=subprocess.run(["py","telegram_test.py"],cwd=str(root),capture_output=True,text=True,encoding="utf-8",errors="replace")
payload=read_json(r"storage\state_control\enrich_first_real_listing_payload_v1.json")
runtime=read_json(r"storage\runtime\current_runtime_state_v1.json")
scripts=globlist("**/*publish*.py",80)
photos=globlist("**/*jpg",30)+globlist("**/*jpeg",30)+globlist("**/*png",30)+globlist("**/*webp",30)
approval_files=globlist("storage/approval/*.json",50)
state_files=globlist("storage/state_control/*.json",80)
checks={"payload_enriched_ok":payload.get("status")=="OK","runtime_exists":exists(r"storage\runtime\current_runtime_state_v1.json"),"telegram_getme_ok":"HTTP STATUS: 200" in (telegram.stdout+telegram.stderr),"telegram_conflict_means_active_polling":"409" in (telegram.stdout+telegram.stderr),"publish_scripts_found":len(scripts)>0,"photos_found":len(photos)>0,"publish_still_locked":payload.get("enriched_payload",{}).get("publish_allowed") is False}
missing=[]
ep=payload.get("enriched_payload",{})
for k in ["title","description_html","sku","price","quantity","category_id","condition"]:
    if not ep.get(k): missing.append(k)
if not photos: missing.append("real_images")
next_action="prepare_first_listing_telegram_approval_packet_v1" if checks["payload_enriched_ok"] and checks["telegram_getme_ok"] and checks["publish_scripts_found"] and not missing else "repair_first_listing_resources_before_approval_v1"
out={"status":"OK" if next_action.startswith("prepare") else "CHECK_NEEDED","layer":"FULL_PRE_PUBLISH_RESOURCE_AUDIT_V1","git_last_commit":git_log.stdout.strip(),"git_status_short":git_status.stdout.strip(),"checks":checks,"missing_before_approval":missing,"selected_payload":ep,"publish_scripts":scripts,"photo_candidates_sample":photos[:40],"approval_files":approval_files,"runtime_state":runtime,"telegram_test_tail":(telegram.stdout+telegram.stderr)[-1200:],"publish_called":False,"push_called":False,"next_allowed_action":next_action,"timestamp":datetime.datetime.now(datetime.timezone.utc).isoformat()}
target=root/r"storage\state_control\full_pre_publish_resource_audit_v1.json"
target.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding="utf-8")
print(json.dumps(out,ensure_ascii=False,indent=2))